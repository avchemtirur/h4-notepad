package com.h4notepad.bridge

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.h4notepad.H4Application
import com.h4notepad.MainActivity
import com.h4notepad.R
import com.h4notepad.data.*
import com.h4notepad.reminder.ReminderScheduler
import com.h4notepad.utils.PrefsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class H4Bridge(private val activity: MainActivity, private val webView: WebView) {

    private val db = (activity.application as H4Application).database
    private val prefs = PrefsManager(activity)
    private val gson = Gson()
    private var mediaPlayer: MediaPlayer? = null

    @JavascriptInterface
    fun isNativeAndroid(): Boolean = true

    @JavascriptInterface
    fun checkExactAlarmPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = activity.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    @JavascriptInterface
    fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${activity.packageName}")
            }
            activity.startActivity(intent)
        }
    }

    @JavascriptInterface
    fun checkBatteryOptimization(): Boolean {
        val powerManager = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(activity.packageName)
    }

    @JavascriptInterface
    fun requestIgnoreBatteryOptimization() {
        if (!checkBatteryOptimization()) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${activity.packageName}")
            }
            activity.startActivity(intent)
        }
    }

    @JavascriptInterface
    fun saveDraft(json: String) {
        prefs.draftJson = json
    }

    @JavascriptInterface
    fun loadDraft(): String {
        return prefs.draftJson ?: ""
    }

    @JavascriptInterface
    fun clearDraft() {
        prefs.draftJson = null
    }

    @JavascriptInterface
    fun loadAllData(callbackJs: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val customers = db.appDao().getAllCustomers()
            val items = db.appDao().getAllItems()
            val contacts = db.appDao().getAllContacts()
            val notes = db.appDao().getAllNotes()
            val followups = db.appDao().getAllFollowUps()
            val reminders = db.appDao().getAllReminders()
            val categories = db.appDao().getAllCategories()
            val settingsList = db.appDao().getAllSettings()

            val settingsMap = settingsList.associate { it.key to it.value }

            val map = mapOf(
                "customers" to customers,
                "items" to items,
                "contacts" to contacts,
                "notes" to notes,
                "followups" to followups,
                "reminders" to reminders,
                "customerCategories" to categories,
                "settings" to settingsMap
            )
            val json = gson.toJson(map)

            withContext(Dispatchers.Main) {
                webView.evaluateJavascript("$callbackJs('$json')", null)
            }
        }
    }

    @JavascriptInterface
    fun saveAllData(json: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val mapType = object : TypeToken<Map<String, Any>>() {}.type
                val map: Map<String, Any> = gson.fromJson(json, mapType)

                val custJson = gson.toJson(map["customers"])
                val custList: List<CustomerEntity> = gson.fromJson(custJson, object : TypeToken<List<CustomerEntity>>() {}.type) ?: emptyList()
                db.appDao().insertCustomers(custList)

                val itemJson = gson.toJson(map["items"])
                val itemList: List<ItemEntity> = gson.fromJson(itemJson, object : TypeToken<List<ItemEntity>>() {}.type) ?: emptyList()
                db.appDao().insertItems(itemList)

                val contJson = gson.toJson(map["contacts"])
                val contList: List<ContactEntity> = gson.fromJson(contJson, object : TypeToken<List<ContactEntity>>() {}.type) ?: emptyList()
                db.appDao().insertContacts(contList)

                val noteJson = gson.toJson(map["notes"])
                val noteList: List<NoteEntity> = gson.fromJson(noteJson, object : TypeToken<List<NoteEntity>>() {}.type) ?: emptyList()
                db.appDao().insertNotes(noteList)

                val fuJson = gson.toJson(map["followups"])
                val fuList: List<FollowUpEntity> = gson.fromJson(fuJson, object : TypeToken<List<FollowUpEntity>>() {}.type) ?: emptyList()
                db.appDao().insertFollowUps(fuList)

                val remJson = gson.toJson(map["reminders"])
                val remList: List<ReminderEntity> = gson.fromJson(remJson, object : TypeToken<List<ReminderEntity>>() {}.type) ?: emptyList()
                db.appDao().insertReminders(remList)

                val catJson = gson.toJson(map["customerCategories"])
                val catList: List<CategoryEntity> = gson.fromJson(catJson, object : TypeToken<List<CategoryEntity>>() {}.type) ?: emptyList()
                db.appDao().insertCategories(catList)

                val settingsRaw = map["settings"]
                if (settingsRaw != null) {
                    val settingsJson = gson.toJson(settingsRaw)
                    val settingsMap: Map<String, Any> = gson.fromJson(settingsJson, object : TypeToken<Map<String, Any>>() {}.type)
                    val settingEntities = settingsMap.map { SettingEntity(it.key, it.value.toString()) }
                    db.appDao().insertSettings(settingEntities)
                }

                // Schedule all active reminders
                remList.filter { it.status != "completed" }.forEach { rem ->
                    ReminderScheduler.schedule(activity, rem)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun scheduleReminder(reminderJson: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reminder: ReminderEntity = gson.fromJson(reminderJson, ReminderEntity::class.java)
                db.appDao().insertReminder(reminder)
                ReminderScheduler.schedule(activity, reminder)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun cancelReminder(reminderId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            db.appDao().deleteReminderById(reminderId)
            ReminderScheduler.cancel(activity, reminderId)
        }
    }

    @JavascriptInterface
    fun playTestSound(soundType: String) {
        activity.runOnUiThread {
            try {
                mediaPlayer?.release()
                if (soundType == "Custom" && !prefs.customSoundUri.isNullOrEmpty()) {
                    mediaPlayer = MediaPlayer.create(activity, Uri.parse(prefs.customSoundUri))
                } else {
                    val soundRes = when (soundType) {
                        "Bell" -> R.raw.bell
                        "Alert" -> R.raw.alert
                        else -> R.raw.chime
                    }
                    mediaPlayer = MediaPlayer.create(activity, soundRes)
                }
                mediaPlayer?.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun pickCustomAudioFile() {
        activity.runOnUiThread {
            activity.launchAudioPicker()
        }
    }
}
