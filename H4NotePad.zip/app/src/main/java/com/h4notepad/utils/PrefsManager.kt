package com.h4notepad.utils

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("h4_prefs", Context.MODE_PRIVATE)

    var draftJson: String?
        get() = prefs.getString("draft_json", null)
        set(value) = prefs.edit().putString("draft_json", value).apply()

    var customSoundUri: String?
        get() = prefs.getString("custom_sound_uri", null)
        set(value) = prefs.edit().putString("custom_sound_uri", value).apply()

    var customSoundName: String?
        get() = prefs.getString("custom_sound_name", null)
        set(value) = prefs.edit().putString("custom_sound_name", value).apply()
}
