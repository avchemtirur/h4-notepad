package com.h4notepad

import android.app.Application
import com.h4notepad.data.AppDatabase
import com.h4notepad.reminder.NotificationHelper

class H4Application : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannels(this)
    }
}
