package com.h4notepad.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.h4notepad.MainActivity
import com.h4notepad.R
import com.h4notepad.data.CustomerEntity
import com.h4notepad.data.ReminderEntity
import com.h4notepad.utils.PrefsManager

object NotificationHelper {

    const val CHANNEL_ID_MISSED = "h4_missed_channel"

    fun getChannelIdForSound(soundType: String, customUri: String?): String {
        return if (soundType == "Custom" && !customUri.isNullOrEmpty()) {
            "h4_alarm_custom_" + Math.abs(customUri.hashCode())
        } else {
            "h4_alarm_" + soundType.lowercase()
        }
    }

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val audioAttr = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val sounds = listOf(
                Pair("default", Uri.parse("android.resource://${context.packageName}/${R.raw.chime}")),
                Pair("chime", Uri.parse("android.resource://${context.packageName}/${R.raw.chime}")),
                Pair("bell", Uri.parse("android.resource://${context.packageName}/${R.raw.bell}")),
                Pair("alert", Uri.parse("android.resource://${context.packageName}/${R.raw.alert}"))
            )

            for ((name, uri) in sounds) {
                val channel = NotificationChannel(
                    "h4_alarm_$name",
                    "Reminder Sound ($name)",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 300, 150, 300, 150, 400)
                    setSound(uri, audioAttr)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }

            val missedChannel = NotificationChannel(
                CHANNEL_ID_MISSED,
                "Missed Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(missedChannel)
        }
    }

    fun showReminderNotification(context: Context, reminder: ReminderEntity, customer: CustomerEntity?) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prefs = PrefsManager(context)
        val channelId = getChannelIdForSound(reminder.sound, prefs.customSoundUri)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (notificationManager.getNotificationChannel(channelId) == null) {
                val audioAttr = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
                val soundUri = if (reminder.sound == "Custom" && !prefs.customSoundUri.isNullOrEmpty()) {
                    Uri.parse(prefs.customSoundUri)
                } else {
                    Uri.parse("android.resource://${context.packageName}/${R.raw.chime}")
                }
                val channel = NotificationChannel(
                    channelId,
                    "Reminder Sound (${reminder.sound})",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 300, 150, 300, 150, 400)
                    setSound(soundUri, audioAttr)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                }
                notificationManager.createNotificationChannel(channel)
            }
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("route", "customer")
            putExtra("customer_id", reminder.customerId)
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            reminder.id.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val callIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "com.h4notepad.ACTION_CALL"
            putExtra("mobile", customer?.mobile ?: "")
            putExtra("reminder_id", reminder.id)
        }
        val callPendingIntent = PendingIntent.getBroadcast(
            context,
            (reminder.id + "_call").hashCode(),
            callIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "com.h4notepad.ACTION_COMPLETE"
            putExtra("reminder_id", reminder.id)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context,
            (reminder.id + "_comp").hashCode(),
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "com.h4notepad.ACTION_SNOOZE_1H"
            putExtra("reminder_id", reminder.id)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (reminder.id + "_snz").hashCode(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val customerName = customer?.name ?: "Customer"
        val title = "🔔 Action Reminder: $customerName"
        val body = "${reminder.reason}\nScheduled Time: ${reminder.time}"

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_stat_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(false)
            .setContentIntent(openAppPendingIntent)
            .addAction(R.drawable.ic_call, "Call", callPendingIntent)
            .addAction(R.drawable.ic_check, "Complete", completePendingIntent)
            .addAction(R.drawable.ic_snooze, "Snooze 1h", snoozePendingIntent)

        notificationManager.notify(reminder.id.hashCode(), builder.build())
    }

    fun showMissedNotification(context: Context, count: Int) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("route", "reminders")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            9999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID_MISSED)
            .setSmallIcon(R.drawable.ic_stat_reminder)
            .setContentTitle("⚠️ Missed Reminders Detected")
            .setContentText("You have $count missed customer reminder(s) while the device was offline.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        notificationManager.notify(9999, builder.build())
    }
}
