package com.h4notepad.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromStringList(value: List<String>?): String {
        return gson.toJson(value ?: emptyList<String>())
    }

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrEmpty()) return emptyList()
        val listType = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, listType)
    }

    @TypeConverter
    fun fromAttachmentList(value: List<AttachmentModel>?): String {
        return gson.toJson(value ?: emptyList<AttachmentModel>())
    }

    @TypeConverter
    fun toAttachmentList(value: String?): List<AttachmentModel> {
        if (value.isNullOrEmpty()) return emptyList()
        val listType = object : TypeToken<List<AttachmentModel>>() {}.type
        return gson.fromJson(value, listType)
    }
}

data class AttachmentModel(
    val name: String,
    val type: String,
    val size: Long,
    val dataUrl: String
)

@Entity(tableName = "customers")
@TypeConverters(Converters::class)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val mobile: String,
    val whatsapp: String = "",
    val altMobile: String = "",
    val address: String = "",
    val location: String = "",
    val items: List<String> = emptyList(),
    val archived: Boolean = false,
    val createdAt: String
)

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val icon: String = "🧪",
    val image: String? = null,
    val description: String = "",
    val active: Boolean = true
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val category: String,
    val method: String,
    val date: String,
    val time: String,
    val details: String,
    val createdAt: String
)

@Entity(tableName = "notes")
@TypeConverters(Converters::class)
data class NoteEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val title: String,
    val body: String,
    val category: String,
    val attachments: List<AttachmentModel> = emptyList(),
    val createdAt: String
)

@Entity(tableName = "followups")
data class FollowUpEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val required: Boolean,
    val completed: Boolean = false,
    val date: String,
    val time: String,
    val reason: String,
    val method: String,
    val priority: String,
    val createdAt: String
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val relatedNoteId: String? = null,
    val relatedFollowupId: String? = null,
    val date: String,
    val time: String,
    val reason: String,
    val method: String,
    val priority: String,
    val sound: String = "Default",
    val vibration: Boolean = true,
    val repeat: String = "none",
    val remindBefore: String = "0",
    val status: String = "pending",
    val snoozeUntil: String? = null,
    val completedNote: String? = null,
    val completedAt: String? = null,
    val notified: Boolean = false,
    val createdAt: String
)

@Entity(tableName = "customer_categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val icon: String,
    val label: String
)

@Entity(tableName = "app_settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
