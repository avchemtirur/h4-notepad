package com.h4notepad.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.h4notepad.H4Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        val db = (context.applicationContext as H4Application).database
        val now = System.currentTimeMillis()
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

        CoroutineScope(Dispatchers.IO).launch {
            val activeReminders = db.appDao().getActiveReminders()
            var missedCount = 0

            for (reminder in activeReminders) {
                try {
                    val date = format.parse("${reminder.date} ${reminder.time}") ?: continue
                    if (date.time <= now) {
                        if (!reminder.notified) {
                            db.appDao().insertReminder(reminder.copy(status = "missed"))
                            missedCount++
                        }
                    } else {
                        ReminderScheduler.schedule(context, reminder)
                    }
                } catch (e: Exception) {
                    // Skip unparseable dates safely
                }
            }

            if (missedCount > 0) {
                NotificationHelper.showMissedNotification(context, missedCount)
            }
        }
    }
}
