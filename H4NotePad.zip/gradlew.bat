@rem
@gradle %*
