package com.h4notepad.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.h4notepad.H4Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra("reminder_id") ?: return
        val db = (context.applicationContext as H4Application).database

        CoroutineScope(Dispatchers.IO).launch {
            val reminder = db.appDao().getReminderById(reminderId) ?: return@launch
            if (reminder.status == "completed") return@launch

            val customer = db.appDao().getCustomerById(reminder.customerId)
            db.appDao().insertReminder(reminder.copy(notified = true))
            NotificationHelper.showReminderNotification(context, reminder, customer)
        }
    }
}
