package com.h4notepad.reminder

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.h4notepad.H4Application
import com.h4notepad.data.ReminderEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra("reminder_id") ?: return
        val db = (context.applicationContext as H4Application).database
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        when (intent.action) {
            "com.h4notepad.ACTION_CALL" -> {
                val mobile = intent.getStringExtra("mobile") ?: ""
                if (mobile.isNotEmpty()) {
                    val callIntent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:$mobile")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(callIntent)
                }
            }
            "com.h4notepad.ACTION_COMPLETE" -> {
                notificationManager.cancel(reminderId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    val reminder = db.appDao().getReminderById(reminderId) ?: return@launch
                    val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("UTC")
                    }.format(Date())

                    db.appDao().insertReminder(
                        reminder.copy(
                            status = "completed",
                            completedAt = nowIso,
                            completedNote = "Completed from notification action"
                        )
                    )

                    // Recurring Reminder Next Occurrence Calculation
                    if (reminder.repeat != "none") {
                        val nextDate = ReminderScheduler.computeNextRecurringDate(reminder.date, reminder.repeat)
                        val newReminder = ReminderEntity(
                            id = "rem_" + UUID.randomUUID().toString().substring(0, 8),
                            customerId = reminder.customerId,
                            relatedNoteId = reminder.relatedNoteId,
                            relatedFollowupId = reminder.relatedFollowupId,
                            date = nextDate,
                            time = reminder.time,
                            reason = reminder.reason,
                            method = reminder.method,
                            priority = reminder.priority,
                            sound = reminder.sound,
                            vibration = reminder.vibration,
                            repeat = reminder.repeat,
                            remindBefore = reminder.remindBefore,
                            status = "pending",
                            notified = false,
                            createdAt = nowIso
                        )
                        db.appDao().insertReminder(newReminder)
                        ReminderScheduler.schedule(context, newReminder)
                    }
                }
            }
            "com.h4notepad.ACTION_SNOOZE_1H" -> {
                notificationManager.cancel(reminderId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    val reminder = db.appDao().getReminderById(reminderId) ?: return@launch
                    val snoozeDate = Date(System.currentTimeMillis() + 3600000L)
                    val snoozeIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("UTC")
                    }.format(snoozeDate)

                    val updated = reminder.copy(
                        status = "snoozed",
                        snoozeUntil = snoozeIso,
                        notified = false
                    )
                    db.appDao().insertReminder(updated)
                    ReminderScheduler.schedule(context, updated)
                }
            }
        }
    }
}
